#include "hashtable.h"

int main() {
  HashTable h = HashTable ();
  h.insert("something",{});

  //::testing::InitGoogleTest(&argc, argv);
  //return RUN_ALL_TESTS();
}
