//forth
//get stack
//acess to next tokens
//
