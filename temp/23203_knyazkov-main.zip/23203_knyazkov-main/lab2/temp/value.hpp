#pragma once

class Value{
    //number or string or operator (method)
};
