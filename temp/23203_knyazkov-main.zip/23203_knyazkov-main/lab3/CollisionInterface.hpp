#pragma once
#include "Invaders.hpp"
#include "Player.hpp"


// //rename to objectContext?
// class CollisionInterface {
// public:
// private:
//     Player m_player;
//     Invaders m_invaders;
// };
