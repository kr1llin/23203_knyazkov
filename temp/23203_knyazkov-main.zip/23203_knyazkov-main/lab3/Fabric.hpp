//use this to make enemies of different types??
