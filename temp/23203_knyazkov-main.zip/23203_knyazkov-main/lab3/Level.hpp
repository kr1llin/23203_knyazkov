//   #pragma once
// #include "Player.hpp"
// #include "Invaders.hpp"
// #include "State.hpp"


// #include <SFML/Config.hpp>
// #include <SFML/Graphics.hpp>
// #include <SFML/Graphics/RenderWindow.hpp>
// #include <unordered_map>

// class Level : public State{
// public:
//     void update(float dtAsSeconds, const std::unordered_map<sf::Keyboard::Key, bool>& inputState);
//     void draw(sf::RenderWindow& window);
//     void handleInput(const std::unordered_map<sf::Keyboard::Key, bool>& inputState);
//     void updateObjects(float dtAsSeconds);

// private:
//   // sf::RenderWindow m_Window;

//   Player m_player;
//   Invaders m_invaders;
// };
  