#include "Engine.hpp"

int main() {
  Engine engine;
  engine.start();
}
