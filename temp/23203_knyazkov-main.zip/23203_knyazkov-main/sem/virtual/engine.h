#pragma once
#include "unit.h"
#include <vector>

void moveAllUnits(std::vector<Unit*> units);
